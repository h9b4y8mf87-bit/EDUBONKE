# EduBonke Pre-Pilot Hardening Patch

This patch is built for the current `h9b4y8mf87-bit/EDUBONKE` code shape reviewed on 18 August 2026.

## What it changes

1. **Removes the silent 500-row workspace cutoff**
   - Adds `lib/workspace-loader.ts`.
   - Reads Supabase tables in 250-row pages until all authorised rows are returned.
   - Limits workspace query fan-out to six tables at a time instead of firing every table request simultaneously.
   - Paginates institution members and the super-admin tenant register too.

2. **Connects admissions to student registration and enrolment**
   - Adds a traceable `students.source_application_id`.
   - Adds `enrol_accepted_application(...)`, a database transaction that:
     - locks the accepted application;
     - verifies the caller is a college administrator or academic manager;
     - copies applicant name/email/phone into the student record;
     - creates the enrolment in the same transaction;
     - prevents the same application from being converted twice;
     - checks that an optional class belongs to the accepted programme.
   - Adds an Admissions form that asks only for the college-issued student number, optional period/class, and expected end date.

3. **Makes the schema's `rejected` evidence state reachable**
   - Adds a **Reject** action next to Verify and Return.
   - Records `reviewed_by` and `reviewed_at` for all three review actions.

4. **Adds regression tests**
   - Guards against reintroducing `.limit(500)`.
   - Guards the transactional admissions conversion.
   - Guards the Reject evidence action.

## Apply

From the repository root:

```bash
python apply_patch.py
```

Then run:

```bash
npm test
git diff --check
git status
```

The patcher creates a one-time local backup:

```text
.edubonke-pre-pilot-portal-client.backup.tsx
```

Delete that backup before committing after you have inspected the diff.

## Database migration

The application code depends on:

```text
supabase/migrations/202608180001_pre_pilot_hardening.sql
```

Apply that migration to the same Supabase project used by the live portal before testing the new accepted-applicant enrolment action.

If you are using the Supabase SQL Editor rather than the CLI, paste and run that migration file as one script.

## Dependency hygiene

The patch deliberately does **not** edit `package.json` or `package-lock.json`, because changing one without regenerating and validating the other would make `npm ci` unreliable.

After the functional patch is green, update Next.js and `eslint-config-next` together using npm in the repository so npm regenerates the lockfile, then rerun `npm test` and `npm audit`.

## Browser accessibility verification

The patch does not claim to replace a live-browser accessibility audit. After the build is green, run the deployed portal through axe/Playwright or an equivalent browser-level audit and perform keyboard-only navigation, focus-order, and colour-contrast checks.
